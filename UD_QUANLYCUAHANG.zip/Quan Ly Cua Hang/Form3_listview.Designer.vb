﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3_listview
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim lvcTen As System.Windows.Forms.ColumnHeader
        Me.bCapNhat = New System.Windows.Forms.Button()
        Me.bXoa = New System.Windows.Forms.Button()
        Me.bThem = New System.Windows.Forms.Button()
        Me.tGia = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tTen = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tMa = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lvDanhSach = New System.Windows.Forms.ListView()
        Me.lvcGia = New System.Windows.Forms.ColumnHeader()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbCot = New System.Windows.Forms.RadioButton()
        Me.rbDanhSach = New System.Windows.Forms.RadioButton()
        Me.rbBieuTuong = New System.Windows.Forms.RadioButton()
        lvcTen = New System.Windows.Forms.ColumnHeader()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lvcTen
        '
        lvcTen.Text = "Ten"
        lvcTen.Width = 200
        '
        'bCapNhat
        '
        Me.bCapNhat.Location = New System.Drawing.Point(958, 676)
        Me.bCapNhat.Margin = New System.Windows.Forms.Padding(6)
        Me.bCapNhat.Name = "bCapNhat"
        Me.bCapNhat.Size = New System.Drawing.Size(139, 49)
        Me.bCapNhat.TabIndex = 18
        Me.bCapNhat.Text = "Cap nhat"
        Me.bCapNhat.UseVisualStyleBackColor = True
        '
        'bXoa
        '
        Me.bXoa.Location = New System.Drawing.Point(1133, 676)
        Me.bXoa.Margin = New System.Windows.Forms.Padding(6)
        Me.bXoa.Name = "bXoa"
        Me.bXoa.Size = New System.Drawing.Size(139, 49)
        Me.bXoa.TabIndex = 17
        Me.bXoa.Text = "Xoa"
        Me.bXoa.UseVisualStyleBackColor = True
        '
        'bThem
        '
        Me.bThem.Location = New System.Drawing.Point(780, 676)
        Me.bThem.Margin = New System.Windows.Forms.Padding(6)
        Me.bThem.Name = "bThem"
        Me.bThem.Size = New System.Drawing.Size(139, 49)
        Me.bThem.TabIndex = 16
        Me.bThem.Text = "Them"
        Me.bThem.UseVisualStyleBackColor = True
        '
        'tGia
        '
        Me.tGia.Location = New System.Drawing.Point(893, 548)
        Me.tGia.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.tGia.Name = "tGia"
        Me.tGia.Size = New System.Drawing.Size(201, 39)
        Me.tGia.TabIndex = 15
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(806, 548)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 32)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Gia"
        '
        'tTen
        '
        Me.tTen.Location = New System.Drawing.Point(893, 390)
        Me.tTen.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.tTen.Name = "tTen"
        Me.tTen.Size = New System.Drawing.Size(201, 39)
        Me.tTen.TabIndex = 13
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(806, 390)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 32)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Ten:"
        '
        'tMa
        '
        Me.tMa.Location = New System.Drawing.Point(893, 258)
        Me.tMa.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.tMa.Name = "tMa"
        Me.tMa.Size = New System.Drawing.Size(201, 39)
        Me.tMa.TabIndex = 11
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(806, 258)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 32)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Ma:"
        '
        'lvDanhSach
        '
        Me.lvDanhSach.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {lvcTen, Me.lvcGia})
        Me.lvDanhSach.Location = New System.Drawing.Point(21, 12)
        Me.lvDanhSach.Name = "lvDanhSach"
        Me.lvDanhSach.Size = New System.Drawing.Size(725, 729)
        Me.lvDanhSach.TabIndex = 19
        Me.lvDanhSach.UseCompatibleStateImageBehavior = False
        Me.lvDanhSach.View = System.Windows.Forms.View.Details
        '
        'lvcGia
        '
        Me.lvcGia.Text = "Gia"
        Me.lvcGia.Width = 200
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbCot)
        Me.GroupBox1.Controls.Add(Me.rbDanhSach)
        Me.GroupBox1.Controls.Add(Me.rbBieuTuong)
        Me.GroupBox1.Location = New System.Drawing.Point(794, 24)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(400, 200)
        Me.GroupBox1.TabIndex = 20
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Hien thi"
        '
        'rbCot
        '
        Me.rbCot.AutoSize = True
        Me.rbCot.Checked = True
        Me.rbCot.Location = New System.Drawing.Point(43, 124)
        Me.rbCot.Name = "rbCot"
        Me.rbCot.Size = New System.Drawing.Size(82, 36)
        Me.rbCot.TabIndex = 2
        Me.rbCot.TabStop = True
        Me.rbCot.Text = "Cot"
        Me.rbCot.UseVisualStyleBackColor = True
        '
        'rbDanhSach
        '
        Me.rbDanhSach.AutoSize = True
        Me.rbDanhSach.Location = New System.Drawing.Point(43, 82)
        Me.rbDanhSach.Name = "rbDanhSach"
        Me.rbDanhSach.Size = New System.Drawing.Size(156, 36)
        Me.rbDanhSach.TabIndex = 1
        Me.rbDanhSach.Text = "Danh sach"
        Me.rbDanhSach.UseVisualStyleBackColor = True
        '
        'rbBieuTuong
        '
        Me.rbBieuTuong.AutoSize = True
        Me.rbBieuTuong.Location = New System.Drawing.Point(43, 40)
        Me.rbBieuTuong.Name = "rbBieuTuong"
        Me.rbBieuTuong.Size = New System.Drawing.Size(163, 36)
        Me.rbBieuTuong.TabIndex = 0
        Me.rbBieuTuong.Text = "Bieu tuong"
        Me.rbBieuTuong.UseVisualStyleBackColor = True
        '
        'Form3_listview
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(13.0!, 32.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1318, 773)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lvDanhSach)
        Me.Controls.Add(Me.bCapNhat)
        Me.Controls.Add(Me.bXoa)
        Me.Controls.Add(Me.bThem)
        Me.Controls.Add(Me.tGia)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.tTen)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.tMa)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form3_listview"
        Me.Text = "Form3_listview"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents bCapNhat As Button
    Friend WithEvents bXoa As Button
    Friend WithEvents bThem As Button
    Friend WithEvents tGia As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents tTen As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents tMa As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents lvDanhSach As ListView
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rbCot As RadioButton
    Friend WithEvents rbDanhSach As RadioButton
    Friend WithEvents rbBieuTuong As RadioButton
    Friend WithEvents lvcGia As ColumnHeader
End Class
