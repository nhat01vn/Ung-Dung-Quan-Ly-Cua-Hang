﻿Public Class frmSanPhamDGV
    Dim dsSanPham As DataTable
    Dim dsSanPhamView As DataView
    Dim dsLoaiSanPham As DataTable


    Private Sub frmSanPhamDGV_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        HienThiDSSanPham(False)

        dsLoaiSanPham = XL_DuLieu.DocDuLieu("Select * from Loai where Loai.Xoa= false")
        cbLoai.DataSource = dsLoaiSanPham
        cbLoai.DisplayMember = "Ten"
        cbLoai.ValueMember = "Ma"
    End Sub

    Sub HienThiDSSanPham(ByVal HienThiTatCa As Boolean)
        If HienThiTatCa Then

            dsSanPham = XL_DuLieu.DocDuLieu("Select SanPham.*, Loai.Ten as Ten_Loai from SanPham, Loai where SanPham.Loai=Loai.Ma ")
        Else
            dsSanPham = XL_DuLieu.DocDuLieu("Select SanPham.*, Loai.Ten as Ten_Loai from SanPham, Loai where SanPham.Loai=Loai.Ma and SanPham.Xoa = False")
        End If

        dsSanPhamView = New DataView(dsSanPham)
        dgvDanhSach.DataSource = dsSanPhamView

        dgvDanhSach.Columns(4).Visible = False
        dgvDanhSach.Columns(5).Visible = False
        dgvDanhSach.Columns(6).HeaderText = "Loai"
    End Sub


    Private Sub btThem_Click(sender As Object, e As EventArgs) Handles btThem.Click
        Dim sp As DataRow = dsSanPham.NewRow()
        sp("Code") = tbCode.Text
        sp("Ten") = tbTen.Text
        sp("Gia") = tbGia.Text
        sp("Loai") = cbLoai.SelectedItem("Ma")
        sp("Xoa") = False
        sp("Ten_Loai") = cbLoai.SelectedItem("Ten")


        dsSanPham.Rows.Add(sp)
        XL_DuLieu.GhiDuLieu("SanPham", dsSanPham)
    End Sub

    Private Sub dgvDanhSach_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvDanhSach.CellClick
        If dgvDanhSach.SelectedCells.Count > 0 Then
            Dim ViTri As Integer = dgvDanhSach.SelectedCells(0).RowIndex
            Dim spv As DataRowView = dgvDanhSach.Rows(ViTri).DataBoundItem
            Dim sp As DataRow = spv.Row
            tbCode.Text = sp("Code")
            tbTen.Text = sp("Ten")
            tbGia.Text = sp("Gia")
            cbLoai.SelectedValue = sp("Loai")
        End If
    End Sub

    Private Sub btCapNhat_Click(sender As Object, e As EventArgs) Handles btCapNhat.Click
        If dgvDanhSach.SelectedCells.Count > 0 Then
            Dim ViTri As Integer = dgvDanhSach.SelectedCells(0).RowIndex
            Dim spv As DataRowView = dgvDanhSach.Rows(ViTri).DataBoundItem
            Dim sp As DataRow = spv.Row
            If sp("Xoa") = False Then
                sp("Code") = tbCode.Text
                sp("Ten") = tbTen.Text
                sp("Gia") = tbGia.Text
                sp("Loai") = cbLoai.SelectedItem("Ma")
                sp("Xoa") = False
                sp("Ten_Loai") = cbLoai.SelectedItem("Ten")

                XL_DuLieu.GhiDuLieu("SanPham", dsSanPham)
            Else
                MessageBox.Show("San pham da bi xoa khong the cap nhat",
"Thong bao", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Else
            MessageBox.Show("Vui long chon san pham truoc khi cap nhat",
"Thong bao", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub btXoa_Click(sender As Object, e As EventArgs) Handles btXoa.Click
        If dgvDanhSach.SelectedCells.Count > 0 Then
            Dim ViTri As Integer = dgvDanhSach.SelectedCells(0).RowIndex
            Dim spv As DataRowView = dgvDanhSach.Rows(ViTri).DataBoundItem
            Dim sp As DataRow = spv.Row
            If sp("Xoa") = False Then
                sp("Xoa") = True

                XL_DuLieu.GhiDuLieu("SanPham", dsSanPham)
                If cbHienThiTatCa.Checked = False Then
                    dsSanPham.Rows.Remove(sp)
                End If
            Else
                MessageBox.Show("Vui long chon san pham de xoa",
"Thong bao", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Else
            MessageBox.Show("Vui long chon san pham de xoa",
"Thong bao", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub tbTimKiem_TextChanged(sender As Object, e As EventArgs) Handles tbTimKiem.TextChanged
        If tbTimKiem.Text = "" Then
            dsSanPhamView.RowFilter = ""
        Else
            dsSanPhamView.RowFilter = String.Format("Ten like '%{0}%'
                                Or Code like '%{0}%'", tbTimKiem.Text)
        End If
    End Sub

    Private Sub cbHienThiTatCa_CheckedChanged(sender As Object, e As EventArgs) Handles cbHienThiTatCa.CheckedChanged
        HienThiDSSanPham(cbHienThiTatCa.Checked)
    End Sub

    Private Sub dgvDanhSach_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles dgvDanhSach.CellFormatting
        Dim str As String = ""
        For Each dgvr As DataGridViewRow In dgvDanhSach.Rows
            Dim spv As DataRowView = dgvr.DataBoundItem
            If spv IsNot Nothing Then
                Dim sp As DataRow = spv.Row

                If sp("Xoa") = False Then
                    str = str + " " + sp("Ma").ToString()
                    dgvr.DefaultCellStyle.BackColor = Color.White
                Else
                    dgvr.DefaultCellStyle.BackColor = Color.Red
                End If
            End If
        Next
    End Sub

    Private Sub btKhoiPhuc_Click(sender As Object, e As EventArgs) Handles btKhoiPhuc.Click
        If dgvDanhSach.SelectedCells.Count > 0 Then
            Dim ViTri As Integer = dgvDanhSach.SelectedCells(0).RowIndex
            Dim spv As DataRowView = dgvDanhSach.Rows(ViTri).DataBoundItem
            Dim sp As DataRow = spv.Row
            If sp("Xoa") = True Then
                sp("Xoa") = False

                XL_DuLieu.GhiDuLieu("SanPham", dsSanPham)
            Else
                MessageBox.Show("San pham chua bi xoa nen k can khoi phuc",
"Thong bao", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Else
            MessageBox.Show("Vui long chon san pham de khoi phuc",
"Thong bao", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

    End Sub
End Class
