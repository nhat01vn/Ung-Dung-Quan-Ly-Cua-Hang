﻿Public Class Form4DocCSDL
    Private Sub Form4DocCSDL_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim dt As DataTable = XL_DuLieu.DocDuLieu("Select SanPham.*,Loai.Ten,Loai.Ma from SanPham, Loai where SanPham.Loai=Loai.Ma")
        DataGridView1.DataSource = dt

    End Sub
End Class
