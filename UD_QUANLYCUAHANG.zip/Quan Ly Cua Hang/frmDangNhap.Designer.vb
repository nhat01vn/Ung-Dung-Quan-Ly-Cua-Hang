﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDangNhap
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tbTenDangNhap = New System.Windows.Forms.TextBox()
        Me.tbMatKhau = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.bDangNhap = New System.Windows.Forms.Button()
        Me.bThoat = New System.Windows.Forms.Button()
        Me.lKetQua = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'tbTenDangNhap
        '
        Me.tbTenDangNhap.Location = New System.Drawing.Point(242, 143)
        Me.tbTenDangNhap.Name = "tbTenDangNhap"
        Me.tbTenDangNhap.Size = New System.Drawing.Size(355, 39)
        Me.tbTenDangNhap.TabIndex = 0
        '
        'tbMatKhau
        '
        Me.tbMatKhau.Location = New System.Drawing.Point(242, 247)
        Me.tbMatKhau.Name = "tbMatKhau"
        Me.tbMatKhau.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.tbMatKhau.Size = New System.Drawing.Size(355, 39)
        Me.tbMatKhau.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(57, 143)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(179, 32)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Ten dang nhap:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(116, 250)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(120, 32)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Mat khau:"
        '
        'bDangNhap
        '
        Me.bDangNhap.Location = New System.Drawing.Point(428, 307)
        Me.bDangNhap.Name = "bDangNhap"
        Me.bDangNhap.Size = New System.Drawing.Size(150, 46)
        Me.bDangNhap.TabIndex = 4
        Me.bDangNhap.Text = "Dang nhap"
        Me.bDangNhap.UseVisualStyleBackColor = True
        '
        'bThoat
        '
        Me.bThoat.Location = New System.Drawing.Point(428, 391)
        Me.bThoat.Name = "bThoat"
        Me.bThoat.Size = New System.Drawing.Size(150, 46)
        Me.bThoat.TabIndex = 5
        Me.bThoat.Text = "Thoat"
        Me.bThoat.UseVisualStyleBackColor = True
        '
        'lKetQua
        '
        Me.lKetQua.AutoSize = True
        Me.lKetQua.Location = New System.Drawing.Point(242, 476)
        Me.lKetQua.Name = "lKetQua"
        Me.lKetQua.Size = New System.Drawing.Size(167, 32)
        Me.lKetQua.TabIndex = 6
        Me.lKetQua.Text = "Dang ket noi..."
        '
        'frmDangNhap
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(13.0!, 32.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(871, 558)
        Me.Controls.Add(Me.lKetQua)
        Me.Controls.Add(Me.bThoat)
        Me.Controls.Add(Me.bDangNhap)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.tbMatKhau)
        Me.Controls.Add(Me.tbTenDangNhap)
        Me.Name = "frmDangNhap"
        Me.Text = "frmDangNhap"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents tbTenDangNhap As TextBox
    Friend WithEvents tbMatKhau As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents bDangNhap As Button
    Friend WithEvents bThoat As Button
    Friend WithEvents lKetQua As Label
End Class
