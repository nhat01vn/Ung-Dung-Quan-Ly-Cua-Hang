﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDS_SanPham
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbDanhSach = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tMa = New System.Windows.Forms.TextBox()
        Me.tTen = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tGia = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.bThem = New System.Windows.Forms.Button()
        Me.bXoa = New System.Windows.Forms.Button()
        Me.bCapNhat = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lbDanhSach
        '
        Me.lbDanhSach.FormattingEnabled = True
        Me.lbDanhSach.ItemHeight = 32
        Me.lbDanhSach.Location = New System.Drawing.Point(11, 13)
        Me.lbDanhSach.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.lbDanhSach.Name = "lbDanhSach"
        Me.lbDanhSach.Size = New System.Drawing.Size(596, 772)
        Me.lbDanhSach.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(665, 64)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 32)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Ma:"
        '
        'tMa
        '
        Me.tMa.Location = New System.Drawing.Point(752, 64)
        Me.tMa.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.tMa.Name = "tMa"
        Me.tMa.Size = New System.Drawing.Size(201, 39)
        Me.tMa.TabIndex = 2
        '
        'tTen
        '
        Me.tTen.Location = New System.Drawing.Point(752, 196)
        Me.tTen.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.tTen.Name = "tTen"
        Me.tTen.Size = New System.Drawing.Size(201, 39)
        Me.tTen.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(665, 196)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 32)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Ten:"
        '
        'tGia
        '
        Me.tGia.Location = New System.Drawing.Point(752, 354)
        Me.tGia.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.tGia.Name = "tGia"
        Me.tGia.Size = New System.Drawing.Size(201, 39)
        Me.tGia.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(665, 354)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 32)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Gia"
        '
        'bThem
        '
        Me.bThem.Location = New System.Drawing.Point(639, 482)
        Me.bThem.Margin = New System.Windows.Forms.Padding(6)
        Me.bThem.Name = "bThem"
        Me.bThem.Size = New System.Drawing.Size(139, 49)
        Me.bThem.TabIndex = 7
        Me.bThem.Text = "Them"
        Me.bThem.UseVisualStyleBackColor = True
        '
        'bXoa
        '
        Me.bXoa.Location = New System.Drawing.Point(992, 482)
        Me.bXoa.Margin = New System.Windows.Forms.Padding(6)
        Me.bXoa.Name = "bXoa"
        Me.bXoa.Size = New System.Drawing.Size(139, 49)
        Me.bXoa.TabIndex = 8
        Me.bXoa.Text = "Xoa"
        Me.bXoa.UseVisualStyleBackColor = True
        '
        'bCapNhat
        '
        Me.bCapNhat.Location = New System.Drawing.Point(817, 482)
        Me.bCapNhat.Margin = New System.Windows.Forms.Padding(6)
        Me.bCapNhat.Name = "bCapNhat"
        Me.bCapNhat.Size = New System.Drawing.Size(139, 49)
        Me.bCapNhat.TabIndex = 9
        Me.bCapNhat.Text = "Cap nhat"
        Me.bCapNhat.UseVisualStyleBackColor = True
        '
        'frmDS_SanPham
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(13.0!, 32.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1218, 809)
        Me.Controls.Add(Me.bCapNhat)
        Me.Controls.Add(Me.bXoa)
        Me.Controls.Add(Me.bThem)
        Me.Controls.Add(Me.tGia)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.tTen)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.tMa)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lbDanhSach)
        Me.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.Name = "frmDS_SanPham"
        Me.Text = "frmDS_SanPham"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbDanhSach As ListBox
    Friend WithEvents Label1 As Label
    Friend WithEvents tMa As TextBox
    Friend WithEvents tTen As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents tGia As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents bThem As Button
    Friend WithEvents bXoa As Button
    Friend WithEvents bCapNhat As Button
End Class
