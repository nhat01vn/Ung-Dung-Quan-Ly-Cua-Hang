﻿Public Class frmNguoiDung
    Dim dsNguoiDung As DataTable
    Dim dsTaiKhoan As DataTable

    Private Sub frmNguoiDung_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim sql As String = "Select NguoiDung.*, TenDangNhap,MatKhau from NguoiDung, TaiKhoan Where MaTaiKhoan = TaiKhoan.Ma and NguoiDung.Xoa = false"

        dsNguoiDung = XL_DuLieu.DocDuLieu(sql)
        dgvDanhSach.DataSource = dsNguoiDung

        dgvDanhSach.Columns(4).Visible = False
        dgvDanhSach.Columns(6).Visible = False
        dgvDanhSach.Columns(8).Visible = False

        sql = "Select TaiKhoan.* from TaiKhoan"
        dsTaiKhoan = XL_DuLieu.DocDuLieu(sql)
    End Sub

    Private Sub btThem_Click(sender As Object, e As EventArgs) Handles btThem.Click
        Dim tk As DataRow = dsTaiKhoan.NewRow()

        tk("TenDangNhap") = tbTenDangNhap.Text
        tk("MatKhau") = Util.getHash(tbMatKhau.Text)
        tk("Xoa") = False
        dsTaiKhoan.Rows.Add(tk)
        XL_DuLieu.GhiDuLieu("TaiKhoan", dsTaiKhoan)

        Dim nd As DataRow = dsNguoiDung.NewRow()
        nd("HoTen") = tbHoTen.Text
        nd("DiaChi") = tbDiaChi.Text
        nd("NgaySinh") = dtpNgaySinh.Value
        nd("DienThoai") = tbDienThoai.Text
        nd("Xoa") = False
        nd("MaTaiKhoan") = tk("Ma")
        nd("TenDangNhap") = tbTenDangNhap.Text
        nd("MatKhau") = tk("MatKhau")
        dsNguoiDung.Rows.Add(nd)
        XL_DuLieu.GhiDuLieu("NguoiDung", dsNguoiDung)

    End Sub

    Private Sub dgvDanhSach_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvDanhSach.CellClick
        If dgvDanhSach.SelectedCells.Count > 0 Then
            Dim ViTri As Integer = dgvDanhSach.SelectedCells(0).RowIndex
            Dim ndv As DataRowView = dgvDanhSach.Rows(ViTri).DataBoundItem
            Dim nd As DataRow = ndv.Row
            tbHoTen.Text = nd("HoTen")
            tbDiaChi.Text = nd("DiaChi")
            dtpNgaySinh.Value = nd("NgaySinh")
            tbDienThoai.Text = nd("DienThoai")
            tbTenDangNhap.Text = nd("TenDangNhap")
            tbMatKhau.Text = ""
        End If
    End Sub

    Private Sub btCapNhat_Click(sender As Object, e As EventArgs) Handles btCapNhat.Click
        If dgvDanhSach.SelectedCells.Count > 0 Then
            Dim ViTri As Integer = dgvDanhSach.SelectedCells(0).RowIndex
            Dim ndv As DataRowView = dgvDanhSach.Rows(ViTri).DataBoundItem
            Dim nd As DataRow = ndv.Row
            nd("HoTen") = tbHoTen.Text
            nd("DiaChi") = tbDiaChi.Text
            nd("NgaySinh") = dtpNgaySinh.Value
            nd("DienThoai") = tbDienThoai.Text
            nd("TenDangNhap") = tbTenDangNhap.Text
            nd("MatKhau") = Util.getHash(tbMatKhau.Text)
            XL_DuLieu.GhiDuLieu("NguoiDung", dsNguoiDung)

            Dim dstk() As DataRow = dsTaiKhoan.Select(String.Format("Ma={0}",
                                                        nd("MaTaiKhoan")))
            Dim tk As DataRow = dstk(0)
            tk("TenDangNhap") = tbTenDangNhap.Text
            tk("MatKhau") = nd("MatKhau")
            XL_DuLieu.GhiDuLieu("TaiKhoan", dsTaiKhoan)
        End If
    End Sub

    Private Sub btXoa_Click(sender As Object, e As EventArgs) Handles btXoa.Click
        If dgvDanhSach.SelectedCells.Count > 0 Then
            Dim ViTri As Integer = dgvDanhSach.SelectedCells(0).RowIndex
            Dim ndv As DataRowView = dgvDanhSach.Rows(ViTri).DataBoundItem
            Dim nd As DataRow = ndv.Row
            nd("Xoa") = True
            XL_DuLieu.GhiDuLieu("NguoiDung", dsNguoiDung)



            Dim dstk() As DataRow = dsTaiKhoan.Select(String.Format("Ma={0}",
                                                        nd("MaTaiKhoan")))
            Dim tk As DataRow = dstk(0)
            tk("Xoa") = True
            XL_DuLieu.GhiDuLieu("TaiKhoan", dsTaiKhoan)
            dsNguoiDung.Rows.Remove(nd)
            dsTaiKhoan.Rows.Remove(tk)
        End If
    End Sub
End Class
