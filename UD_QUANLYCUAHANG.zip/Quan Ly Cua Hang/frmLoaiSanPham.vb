﻿Public Class frmLoaiSanPham

    Dim dsSanPham As DataTable
    Dim dsLoaiSanPham As DataTable

    Private Sub frmLoaiSanPham_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dsLoaiSanPham = XL_DuLieu.DocDuLieu("Select SanPham.Code, SanPham.Ten, Loai.* from Loai,SanPham where SanPham.Loai=Loai.Ma and SanPham.Xoa=false")
        dgvDanhSachLoai.DataSource = dsLoaiSanPham

        dgvDanhSachLoai.Columns(2).Visible = False
        dgvDanhSachLoai.Columns(4).Visible = False
        dgvDanhSachLoai.Columns(1).HeaderText = "San pham"
        dgvDanhSachLoai.Columns(3).HeaderText = "Loai"
    End Sub

    Private Sub btThem_Click(sender As Object, e As EventArgs) Handles btThem.Click
        Dim sp As DataRow = dsLoaiSanPham.NewRow()

        dsLoaiSanPham.Rows.Add(sp)
        XL_DuLieu.GhiDuLieu("SanPham", dsLoaiSanPham)
    End Sub
End Class
