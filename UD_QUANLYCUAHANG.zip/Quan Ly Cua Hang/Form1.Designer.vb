﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.DSNguoiDungToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DSSanPhamToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DSLoaiSanPhamToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DonHangToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ThongKeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DSNguoiDungToolStripMenuItem, Me.DSSanPhamToolStripMenuItem, Me.DSLoaiSanPhamToolStripMenuItem, Me.DonHangToolStripMenuItem, Me.ThongKeToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(3, 1, 0, 1)
        Me.MenuStrip1.Size = New System.Drawing.Size(815, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'DSNguoiDungToolStripMenuItem
        '
        Me.DSNguoiDungToolStripMenuItem.Name = "DSNguoiDungToolStripMenuItem"
        Me.DSNguoiDungToolStripMenuItem.Size = New System.Drawing.Size(101, 22)
        Me.DSNguoiDungToolStripMenuItem.Text = "DS Nguoi Dung"
        '
        'DSSanPhamToolStripMenuItem
        '
        Me.DSSanPhamToolStripMenuItem.Name = "DSSanPhamToolStripMenuItem"
        Me.DSSanPhamToolStripMenuItem.Size = New System.Drawing.Size(89, 22)
        Me.DSSanPhamToolStripMenuItem.Text = "DS San Pham"
        '
        'DSLoaiSanPhamToolStripMenuItem
        '
        Me.DSLoaiSanPhamToolStripMenuItem.Name = "DSLoaiSanPhamToolStripMenuItem"
        Me.DSLoaiSanPhamToolStripMenuItem.Size = New System.Drawing.Size(114, 22)
        Me.DSLoaiSanPhamToolStripMenuItem.Text = "DS Loai San Pham"
        '
        'DonHangToolStripMenuItem
        '
        Me.DonHangToolStripMenuItem.Name = "DonHangToolStripMenuItem"
        Me.DonHangToolStripMenuItem.Size = New System.Drawing.Size(71, 22)
        Me.DonHangToolStripMenuItem.Text = "Don hang"
        '
        'ThongKeToolStripMenuItem
        '
        Me.ThongKeToolStripMenuItem.Name = "ThongKeToolStripMenuItem"
        Me.ThongKeToolStripMenuItem.Size = New System.Drawing.Size(68, 22)
        Me.ThongKeToolStripMenuItem.Text = "Thong ke"
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(61, 4)
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(815, 483)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
        Me.Name = "Form1"
        Me.Text = "Main"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents DSNguoiDungToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DSSanPhamToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DSLoaiSanPhamToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DonHangToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ThongKeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
End Class
