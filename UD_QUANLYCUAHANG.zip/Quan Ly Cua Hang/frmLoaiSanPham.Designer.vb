﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLoaiSanPham
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvDanhSachLoai = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbTen = New System.Windows.Forms.TextBox()
        Me.btThem = New System.Windows.Forms.Button()
        Me.btCapNhat = New System.Windows.Forms.Button()
        Me.btXoa = New System.Windows.Forms.Button()
        CType(Me.dgvDanhSachLoai, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvDanhSachLoai
        '
        Me.dgvDanhSachLoai.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDanhSachLoai.Location = New System.Drawing.Point(6, 35)
        Me.dgvDanhSachLoai.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
        Me.dgvDanhSachLoai.Name = "dgvDanhSachLoai"
        Me.dgvDanhSachLoai.RowHeadersWidth = 82
        Me.dgvDanhSachLoai.RowTemplate.Height = 41
        Me.dgvDanhSachLoai.Size = New System.Drawing.Size(431, 144)
        Me.dgvDanhSachLoai.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(24, 10)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(85, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Loai San Pham"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(457, 90)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 15)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Ten Loai:"
        '
        'tbTen
        '
        Me.tbTen.Location = New System.Drawing.Point(517, 89)
        Me.tbTen.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
        Me.tbTen.Name = "tbTen"
        Me.tbTen.Size = New System.Drawing.Size(110, 23)
        Me.tbTen.TabIndex = 5
        '
        'btThem
        '
        Me.btThem.Location = New System.Drawing.Point(441, 141)
        Me.btThem.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
        Me.btThem.Name = "btThem"
        Me.btThem.Size = New System.Drawing.Size(81, 22)
        Me.btThem.TabIndex = 8
        Me.btThem.Text = "Them"
        Me.btThem.UseVisualStyleBackColor = True
        '
        'btCapNhat
        '
        Me.btCapNhat.Location = New System.Drawing.Point(544, 141)
        Me.btCapNhat.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
        Me.btCapNhat.Name = "btCapNhat"
        Me.btCapNhat.Size = New System.Drawing.Size(81, 22)
        Me.btCapNhat.TabIndex = 9
        Me.btCapNhat.Text = "Cap nhat"
        Me.btCapNhat.UseVisualStyleBackColor = True
        '
        'btXoa
        '
        Me.btXoa.Location = New System.Drawing.Point(638, 141)
        Me.btXoa.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
        Me.btXoa.Name = "btXoa"
        Me.btXoa.Size = New System.Drawing.Size(81, 22)
        Me.btXoa.TabIndex = 10
        Me.btXoa.Text = "Xoa"
        Me.btXoa.UseVisualStyleBackColor = True
        '
        'frmLoaiSanPham
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(734, 201)
        Me.Controls.Add(Me.btXoa)
        Me.Controls.Add(Me.btCapNhat)
        Me.Controls.Add(Me.btThem)
        Me.Controls.Add(Me.tbTen)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dgvDanhSachLoai)
        Me.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
        Me.Name = "frmLoaiSanPham"
        Me.Text = "frmLoaiSanPham"
        CType(Me.dgvDanhSachLoai, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dgvDanhSachLoai As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents tbTen As TextBox
    Friend WithEvents btThem As Button
    Friend WithEvents btCapNhat As Button
    Friend WithEvents btXoa As Button
End Class
