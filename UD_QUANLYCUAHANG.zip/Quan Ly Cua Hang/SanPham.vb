﻿Public Class SanPham

    Private _ma As String
    Public Property Ma() As String
        Get
            Return _ma
        End Get
        Set(ByVal value As String)
            _ma = value
        End Set
    End Property

    Private _ten As String
    Public Property Ten() As String
        Get
            Return _ten
        End Get
        Set(ByVal value As String)
            _ten = value
        End Set
    End Property

    Private _gia As Integer
    Public Property Gia As Integer
        Get
            Return _gia
        End Get
        Set(ByVal value As Integer)
            _gia = value
        End Set
    End Property

End Class
