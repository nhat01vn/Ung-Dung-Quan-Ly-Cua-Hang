﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSanPhamDGV
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.FileSystemWatcher1 = New System.IO.FileSystemWatcher()
        Me.dgvDanhSach = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.tbCode = New System.Windows.Forms.TextBox()
        Me.tbTen = New System.Windows.Forms.TextBox()
        Me.tbGia = New System.Windows.Forms.TextBox()
        Me.cbLoai = New System.Windows.Forms.ComboBox()
        Me.btThem = New System.Windows.Forms.Button()
        Me.btCapNhat = New System.Windows.Forms.Button()
        Me.btXoa = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.tbTimKiem = New System.Windows.Forms.TextBox()
        Me.cbHienThiTatCa = New System.Windows.Forms.CheckBox()
        Me.btKhoiPhuc = New System.Windows.Forms.Button()
        CType(Me.FileSystemWatcher1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvDanhSach, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'FileSystemWatcher1
        '
        Me.FileSystemWatcher1.EnableRaisingEvents = True
        Me.FileSystemWatcher1.SynchronizingObject = Me
        '
        'dgvDanhSach
        '
        Me.dgvDanhSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDanhSach.Location = New System.Drawing.Point(12, 12)
        Me.dgvDanhSach.Name = "dgvDanhSach"
        Me.dgvDanhSach.RowHeadersWidth = 82
        Me.dgvDanhSach.RowTemplate.Height = 41
        Me.dgvDanhSach.Size = New System.Drawing.Size(1303, 385)
        Me.dgvDanhSach.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(19, 450)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 32)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Ma"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(19, 514)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 32)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Ten"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(19, 586)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 32)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Gia"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(19, 659)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(57, 32)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Loai"
        '
        'tbCode
        '
        Me.tbCode.Location = New System.Drawing.Point(73, 450)
        Me.tbCode.Name = "tbCode"
        Me.tbCode.Size = New System.Drawing.Size(242, 39)
        Me.tbCode.TabIndex = 5
        '
        'tbTen
        '
        Me.tbTen.Location = New System.Drawing.Point(73, 514)
        Me.tbTen.Name = "tbTen"
        Me.tbTen.Size = New System.Drawing.Size(242, 39)
        Me.tbTen.TabIndex = 6
        '
        'tbGia
        '
        Me.tbGia.Location = New System.Drawing.Point(73, 586)
        Me.tbGia.Name = "tbGia"
        Me.tbGia.Size = New System.Drawing.Size(242, 39)
        Me.tbGia.TabIndex = 7
        '
        'cbLoai
        '
        Me.cbLoai.FormattingEnabled = True
        Me.cbLoai.Location = New System.Drawing.Point(73, 659)
        Me.cbLoai.Name = "cbLoai"
        Me.cbLoai.Size = New System.Drawing.Size(242, 40)
        Me.cbLoai.TabIndex = 8
        '
        'btThem
        '
        Me.btThem.Location = New System.Drawing.Point(435, 436)
        Me.btThem.Name = "btThem"
        Me.btThem.Size = New System.Drawing.Size(150, 46)
        Me.btThem.TabIndex = 9
        Me.btThem.Text = "Them"
        Me.btThem.UseVisualStyleBackColor = True
        '
        'btCapNhat
        '
        Me.btCapNhat.Location = New System.Drawing.Point(435, 514)
        Me.btCapNhat.Name = "btCapNhat"
        Me.btCapNhat.Size = New System.Drawing.Size(150, 46)
        Me.btCapNhat.TabIndex = 10
        Me.btCapNhat.Text = "Cap nhat"
        Me.btCapNhat.UseVisualStyleBackColor = True
        '
        'btXoa
        '
        Me.btXoa.Location = New System.Drawing.Point(435, 606)
        Me.btXoa.Name = "btXoa"
        Me.btXoa.Size = New System.Drawing.Size(150, 46)
        Me.btXoa.TabIndex = 11
        Me.btXoa.Text = "Xoa"
        Me.btXoa.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(768, 450)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(229, 32)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Tim kiem san pham:"
        '
        'tbTimKiem
        '
        Me.tbTimKiem.Location = New System.Drawing.Point(768, 495)
        Me.tbTimKiem.Name = "tbTimKiem"
        Me.tbTimKiem.Size = New System.Drawing.Size(263, 39)
        Me.tbTimKiem.TabIndex = 14
        '
        'cbHienThiTatCa
        '
        Me.cbHienThiTatCa.AutoSize = True
        Me.cbHienThiTatCa.Location = New System.Drawing.Point(768, 553)
        Me.cbHienThiTatCa.Name = "cbHienThiTatCa"
        Me.cbHienThiTatCa.Size = New System.Drawing.Size(196, 36)
        Me.cbHienThiTatCa.TabIndex = 15
        Me.cbHienThiTatCa.Text = "Hien thi tat ca"
        Me.cbHienThiTatCa.UseVisualStyleBackColor = True
        '
        'btKhoiPhuc
        '
        Me.btKhoiPhuc.Location = New System.Drawing.Point(435, 694)
        Me.btKhoiPhuc.Name = "btKhoiPhuc"
        Me.btKhoiPhuc.Size = New System.Drawing.Size(150, 46)
        Me.btKhoiPhuc.TabIndex = 16
        Me.btKhoiPhuc.Text = "Khoi phuc"
        Me.btKhoiPhuc.UseVisualStyleBackColor = True
        '
        'frmSanPhamDGV
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(13.0!, 32.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1321, 752)
        Me.Controls.Add(Me.btKhoiPhuc)
        Me.Controls.Add(Me.cbHienThiTatCa)
        Me.Controls.Add(Me.tbTimKiem)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btXoa)
        Me.Controls.Add(Me.btCapNhat)
        Me.Controls.Add(Me.btThem)
        Me.Controls.Add(Me.cbLoai)
        Me.Controls.Add(Me.tbGia)
        Me.Controls.Add(Me.tbTen)
        Me.Controls.Add(Me.tbCode)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dgvDanhSach)
        Me.Name = "frmSanPhamDGV"
        Me.Text = "frmSanPhamDGV"
        CType(Me.FileSystemWatcher1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvDanhSach, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents FileSystemWatcher1 As IO.FileSystemWatcher
    Friend WithEvents dgvDanhSach As DataGridView
    Friend WithEvents tbTimKiem As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents btXoa As Button
    Friend WithEvents btCapNhat As Button
    Friend WithEvents btThem As Button
    Friend WithEvents cbLoai As ComboBox
    Friend WithEvents tbGia As TextBox
    Friend WithEvents tbTen As TextBox
    Friend WithEvents tbCode As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents cbHienThiTatCa As CheckBox
    Friend WithEvents btKhoiPhuc As Button
End Class
