﻿Public Class frmDS_SanPham

    Dim dsSanPham As List(Of SanPham)

    Private Sub frmDS_SanPham_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Doc du lieu tu file/ CSDL
        dsSanPham = New List(Of SanPham)()

        Dim sp = New SanPham()
        sp.Ma = "SP001"
        sp.Ten = "Coca"
        sp.Gia = 1000
        dsSanPham.Add(sp)

        sp = New SanPham()
        sp.Ma = "SP002"
        sp.Ten = "Nuoc"
        sp.Gia = 10000
        dsSanPham.Add(sp)

        sp = New SanPham()
        sp.Ma = "SP003"
        sp.Ten = "Sprite"
        sp.Gia = 12000
        dsSanPham.Add(sp)

        'Hien thi len giao dien
        For Each sp In dsSanPham
            Dim str = String.Format("{0}-{1}", sp.Ma, sp.Ten)
            lbDanhSach.Items.Add(str)
        Next

    End Sub

    Private Sub bThem_Click(sender As Object, e As EventArgs) Handles bThem.Click
        Dim sp As SanPham = New SanPham()
        sp.Ma = tMa.Text
        sp.Ten = tTen.Text
        sp.Gia = tGia.Text

        dsSanPham.Add(sp)


        Dim str = String.Format("{0}-{1}", sp.Ma, sp.Ten)
        lbDanhSach.Items.Add(str)


    End Sub
    Private Sub lbDanhSach_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lbDanhSach.SelectedIndexChanged
        If lbDanhSach.SelectedIndex >= 0 Then
            Dim vitri = lbDanhSach.SelectedIndex
            Dim sp = dsSanPham(vitri)
            tMa.Text = sp.Ma
            tTen.Text = sp.Ten
            tGia.Text = sp.Gia
        End If
    End Sub
    Private Sub bCapNhat_Click(sender As Object, e As EventArgs) Handles bCapNhat.Click
        If lbDanhSach.SelectedIndex >= 0 Then
            Dim vitri = lbDanhSach.SelectedIndex
            Dim sp = dsSanPham(vitri)

            sp.Ma = tMa.Text
            sp.Ten = tTen.Text
            sp.Gia = tGia.Text

            lbDanhSach.Items.RemoveAt(vitri)
            Dim str = String.Format("{0}-{1}", sp.Ma, sp.Ten)
            lbDanhSach.Items.Insert(vitri, str)
        Else
            MessageBox.Show("Anh chi chua chon san pham", "THONG BAO!!")
        End If


    End Sub

    Private Sub bXoa_Click(sender As Object, e As EventArgs) Handles bXoa.Click
        If lbDanhSach.SelectedIndex >= 0 Then
            Dim vitri = lbDanhSach.SelectedIndex
            Dim sp = dsSanPham(vitri)

            Dim dr = MessageBox.Show(String.Format("Anh/chi co muon xoa
xoa san pham"), "THONG BAO", MessageBoxButtons.YesNo)
            If dr = DialogResult.Yes Then
                dsSanPham.RemoveAt(vitri)
                lbDanhSach.Items.RemoveAt(vitri)
            End If


        Else
                MessageBox.Show("Anh chi chua chon san pham", "THONG BAO!!")
        End If

    End Sub
End Class
