﻿Public Class frmDangNhap

    Dim NguoiDung As DataRow

    Private Sub bDangNhap_Click(sender As Object, e As EventArgs) Handles bDangNhap.Click
        Dim TenDangNhap As String = tbTenDangNhap.Text
        Dim MatKhau As String = tbMatKhau.Text
        Dim sql As String = String.Format("Select * from NguoiDung, TaiKhoan where MaTaiKhoan=TaiKhoan.Ma and TenDangNhap='{0}' and NguoiDung.Xoa=false", TenDangNhap)
        Dim dsNDung As DataTable = XL_DuLieu.DocDuLieu(sql)
        If dsNDung.Rows.Count = 1 Then
            NguoiDung = dsNDung.Rows(0)
            If MatKhau = NguoiDung("MatKhau") Then
                Me.DialogResult = DialogResult.OK
            End If
        End If
        Me.DialogResult = DialogResult.OK

    End Sub

    Private Sub bThoat_Click(sender As Object, e As EventArgs) Handles bThoat.Click
        Me.Close()
    End Sub


End Class
