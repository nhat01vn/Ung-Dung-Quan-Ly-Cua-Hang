﻿Public Class Form1
    Dim frmSanPham As frmSanPhamDGV = Nothing
    Private Sub DSSanPhamToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DSSanPhamToolStripMenuItem.Click
        If frmSanPham Is Nothing Then
            frmSanPham = New frmSanPhamDGV()
        ElseIf frmSanPham.IsDisposed Then
            frmSanPham = New frmSanPhamDGV()

        End If

        frmSanPham.MdiParent = Me
        frmSanPham.WindowState = FormWindowState.Maximized
        frmSanPham.Show()
    End Sub

    Dim frmLoaiSanPham1 As frmLoaiSanPham = Nothing
    Private Sub DSLoaiSanPhamToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DSLoaiSanPhamToolStripMenuItem.Click
        If frmLoaiSanPham1 Is Nothing Then
            frmLoaiSanPham1 = New frmLoaiSanPham()
        ElseIf frmSanPham.IsDisposed Then
            frmLoaiSanPham1 = New frmLoaiSanPham()

        End If

        frmLoaiSanPham1.MdiParent = Me
        frmLoaiSanPham1.WindowState = FormWindowState.Maximized
        frmLoaiSanPham1.Show()
    End Sub

    Dim _frmNguoiDung As frmNguoiDung = Nothing
    Private Sub DSNguoiDungToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DSNguoiDungToolStripMenuItem.Click
        If _frmNguoiDung Is Nothing Then
            _frmNguoiDung = New frmNguoiDung()
        ElseIf _frmNguoiDung.IsDisposed Then
            _frmNguoiDung = New frmNguoiDung()

        End If

        _frmNguoiDung.MdiParent = Me
        _frmNguoiDung.WindowState = FormWindowState.Maximized
        _frmNguoiDung.Show()
    End Sub


    Dim _frmDonHang As frmDonHang = Nothing
    Private Sub DonHangToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DonHangToolStripMenuItem.Click
        If _frmDonHang Is Nothing Then
            _frmDonHang = New frmDonHang()
        ElseIf _frmDonHang.IsDisposed Then
            _frmDonHang = New frmDonHang()

        End If

        _frmDonHang.MdiParent = Me
        _frmDonHang.WindowState = FormWindowState.Maximized
        _frmDonHang.Show()
    End Sub

    Dim _frmThongKe As ThongKe = Nothing
    Private Sub ThongKeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ThongKeToolStripMenuItem.Click
        If _frmThongKe Is Nothing Then
            _frmThongKe = New ThongKe()
        ElseIf _frmThongKe.IsDisposed Then
            _frmThongKe = New ThongKe()

        End If

        _frmThongKe.MdiParent = Me
        _frmThongKe.WindowState = FormWindowState.Maximized
        _frmThongKe.Show()
    End Sub


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Hide()
        Dim frm As frmDangNhap = New frmDangNhap()
        Dim dr As DialogResult = frm.ShowDialog()
        If dr = ShowDialog.OK Then
            Me.Show()
        Else
            Me.Close()
        End If
    End Sub


End Class
